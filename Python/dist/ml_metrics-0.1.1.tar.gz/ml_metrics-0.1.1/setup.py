#!/usr/bin/env python2.7

from distutils.core import setup

setup(name='ml_metrics',
      version='0.1.1',
      description='Machine Learning Evaluation Metrics',
      author = 'Ben Hamner',
      author_email = 'ben@benhamner.com',
      packages = ['ml_metrics'])
